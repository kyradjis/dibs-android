package com.sergios.dibs;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
