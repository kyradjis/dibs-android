'use strict';

/* =====================================================================
   Dibs — your discount cards, in one place.
   Data lives on this phone only (localStorage). Location is read only
   while the app is open and visible.
   ===================================================================== */

const KEY = 'dibs.v1';
const LANG = (navigator.language || 'en').split('-')[0];
const DEFAULT_CENTER = [35.1856, 33.3823];
const CATS = ['Food', 'Coffee', 'Shopping', 'Health', 'Leisure', 'Travel', 'Other'];
const COLORS = [
  { a: '#3A57F5', b: '#6B4DFF', s: '#3A57F5' },
  { a: '#F2553F', b: '#FF8A5C', s: '#F2553F' },
  { a: '#0E9F78', b: '#2CCB9B', s: '#0E9F78' },
  { a: '#E58A00', b: '#F7B538', s: '#E58A00' },
  { a: '#C13BD6', b: '#F062B8', s: '#C13BD6' },
  { a: '#222839', b: '#454D66', s: '#2B3144' }
];

const svg = (body, vb = '0 0 24 24') => `<svg class="ic" viewBox="${vb}" aria-hidden="true">${body}</svg>`;
const I = {
  wallet: svg('<rect x="3" y="6" width="18" height="14" rx="3.5"/><path d="M3 10.5h18M16 15.2h1.6"/><path d="M6 6l9-2.5a2 2 0 0 1 2.5 1.9V6"/>'),
  map: svg('<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/>'),
  plus: svg('<path d="M12 5v14M5 12h14"/>'),
  search: svg('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'),
  pin: svg('<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>'),
  pinbig: svg('<path d="M12 22s7.5-6.5 7.5-12A7.5 7.5 0 0 0 4.5 10C4.5 15.5 12 22 12 22z"/><circle cx="12" cy="10" r="2.8"/>'),
  close: svg('<path d="M6 6l12 12M18 6 6 18"/>'),
  check: svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
  locate: svg('<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="7.5"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22"/>'),
  edit: svg('<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4z"/>'),
  sliders: svg('<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>'),
  nav: svg('<path d="M3 11 21 3l-8 18-2-8-8-2z"/>'),
  fit: svg('<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>'),
  down: svg('<path d="M12 4v11m0 0-4-4m4 4 4-4M5 20h14"/>'),
  up: svg('<path d="M12 16V5m0 0-4 4m4-4 4 4M5 20h14"/>'),
  trash: svg('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
  percent: svg('<path d="M19 5 5 19"/><circle cx="7.2" cy="7.2" r="2.4"/><circle cx="16.8" cy="16.8" r="2.4"/>')
};

/* ---------------------------- tiny helpers ---------------------------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
const norm = (s) => String(s || '').trim().toLowerCase();
const initial = (s) => ((String(s).match(/[\p{L}\p{N}]/u) || ['?'])[0]).toUpperCase();

/* ------------------------------- data -------------------------------- */
function load() {
  try {
    const j = JSON.parse(localStorage.getItem(KEY));
    if (j && Array.isArray(j.cards) && Array.isArray(j.discounts)) return j;
  } catch (e) { /* first run or unreadable */ }
  return { cards: [], discounts: [] };
}
let S = load();
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(S)); }
  catch (e) { toast('Couldn’t save. Storage may be full or blocked.'); }
}
const cardOf = (id) => S.cards.find((c) => c.id === id);
const colorOf = (card) => COLORS[(card && card.color) || 0] || COLORS[0];
const discColor = (d) => colorOf(cardOf(d.cardId));

const ui = { tab: 'wallet', cardId: null, cat: '', q: '', nearest: false, mapCard: null, mapMoved: false };

/* ------------------------------ distance ------------------------------ */
function dist(a, b) {
  const t = Math.PI / 180;
  const dLat = (b.lat - a.lat) * t, dLon = (b.lon - a.lon) * t;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * t) * Math.cos(b.lat * t) * Math.sin(dLon / 2) ** 2;
  return 2 * 6371000 * Math.asin(Math.sqrt(x));
}
function fmtDist(m) {
  if (m < 950) return Math.max(10, Math.round(m / 10) * 10) + ' m';
  return (m / 1000).toFixed(m < 10000 ? 1 : 0) + ' km';
}
function nearestDist(d) {
  if (!geo.pos || !d.places || !d.places.length) return null;
  return Math.min(...d.places.map((p) => dist(geo.pos, p)));
}

/* ------------------------------ toast ------------------------------- */
let toastTimer;
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('on'), 3200);
}

/* ----------------------- location (foreground only) ----------------------- */
const geo = { pos: null, watch: null, on: false, denied: false, lastRender: 0 };
const geoWaiters = [];
function enableLocation() {
  if (geo.denied || !('geolocation' in navigator)) return;
  geo.on = true;
  startWatch();
}
function startWatch() {
  if (!geo.on || geo.watch != null || document.hidden || !('geolocation' in navigator)) return;
  geo.watch = navigator.geolocation.watchPosition(onPos, onPosErr, { enableHighAccuracy: true, maximumAge: 20000, timeout: 25000 });
}
function stopWatch() {
  if (geo.watch != null) { navigator.geolocation.clearWatch(geo.watch); geo.watch = null; }
}
function onPos(p) {
  const first = !geo.pos;
  geo.denied = false;
  geo.pos = { lat: p.coords.latitude, lon: p.coords.longitude, acc: p.coords.accuracy };
  updateMeMarker();
  const now = Date.now();
  if (first || now - geo.lastRender > 10000) {
    geo.lastRender = now;
    if (ui.tab === 'wallet') renderList();
  }
  if (first && ui.tab === 'map' && map && !ui.mapMoved) flyToMe();
  geoWaiters.splice(0).forEach((f) => f());
}
function onPosErr(e) {
  if (e && e.code === 1) {
    geo.denied = true; geo.on = false; stopWatch();
    if (ui.nearest) { ui.nearest = false; syncNearBtn(); renderList(); }
    toast('Location is off. Allow it for Dibs in Android settings → Apps → Dibs → Permissions.');
  }
  geoWaiters.splice(0).forEach((f) => f());
}
function ensurePosition(ms = 4000) {
  if (geo.pos) return Promise.resolve(geo.pos);
  enableLocation();
  if (!geo.on) return Promise.resolve(null);
  return new Promise((res) => {
    const t = setTimeout(() => res(geo.pos), ms);
    geoWaiters.push(() => { clearTimeout(t); res(geo.pos); });
  });
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) stopWatch(); else startWatch();
});
window.addEventListener('pagehide', stopWatch);

/* ------------------------------ wallet UI ------------------------------ */
function renderAll() {
  renderWallet();
  if (map) { drawPins(); }
  renderMapChips();
}

function renderWallet() {
  const n = S.discounts.length, m = S.cards.length;
  $('#sub').textContent = n ? `${n} ${n === 1 ? 'discount' : 'discounts'} on ${m} ${m === 1 ? 'card' : 'cards'}` : 'Your discount cards, in one place';
  renderCards();
  renderChips();
  renderList();
}

function renderCards() {
  const count = (id) => S.discounts.filter((d) => d.cardId === id).length;
  if (!S.cards.length) { $('#cards').innerHTML = ''; return; }
  $('#cards').innerHTML = S.cards.map((c) => {
    const k = colorOf(c), n = count(c.id);
    return `<div class="wcard${ui.cardId === c.id ? ' sel' : ''}" role="button" tabindex="0" data-act="pickcard" data-id="${esc(c.id)}" style="--a:${k.a};--b:${k.b}">
      <button class="cedit" data-act="editcard" data-id="${esc(c.id)}" aria-label="Edit ${esc(c.name)}">${I.edit}</button>
      <div class="cname">${esc(c.name)}</div>
      <div class="ccount">${n} ${n === 1 ? 'discount' : 'discounts'}</div>
    </div>`;
  }).join('') + `<button class="wcard new" data-act="newcard"><span class="plus">${I.plus}</span><span>Add a card</span></button>`;
}

function renderChips() {
  const set = [...new Set(S.discounts.filter((d) => !ui.cardId || d.cardId === ui.cardId).map((d) => d.category).filter(Boolean))];
  if (!set.includes(ui.cat)) ui.cat = '';
  $('#chips').innerHTML = set.length < 2 ? '' : ['', ...set].map((c) =>
    `<button class="chip${ui.cat === c ? ' on' : ''}" data-act="cat" data-v="${esc(c)}">${c ? esc(c) : 'All'}</button>`).join('');
  if (set.length < 2) ui.cat = '';
}

function visibleDiscounts() {
  let a = S.discounts.slice();
  if (ui.cardId) a = a.filter((d) => d.cardId === ui.cardId);
  if (ui.cat) a = a.filter((d) => d.category === ui.cat);
  const q = norm(ui.q);
  if (q) a = a.filter((d) => norm([d.shop, d.value, d.notes, d.category, (cardOf(d.cardId) || {}).name].join(' ')).includes(q));
  const items = a.map((d) => ({ d, m: nearestDist(d) }));
  if (ui.nearest) items.sort((x, y) => (x.m ?? Infinity) - (y.m ?? Infinity) || x.d.shop.localeCompare(y.d.shop));
  else items.sort((x, y) => x.d.shop.localeCompare(y.d.shop));
  return items;
}

function renderList() {
  const el = $('#list');
  if (!S.cards.length) {
    el.innerHTML = `<li class="empty"><div class="badge">${I.percent}</div><h2>Start with a card</h2><p>Add a card, like your work perks or tennis club, then list the shops and restaurants it gives you a discount at.</p><button class="btn primary" data-act="newcard">Add a card</button></li>`;
    return;
  }
  const items = visibleDiscounts();
  if (!items.length) {
    const filtering = ui.q || ui.cat;
    el.innerHTML = `<li class="empty"><div class="badge">${I.percent}</div><h2>${filtering ? 'Nothing matches' : 'No discounts yet'}</h2><p>${filtering ? 'Try a different search or filter.' : 'Add the first discount for this card and pin where you can use it.'}</p>${filtering ? '' : '<button class="btn primary" data-act="add">Add a discount</button>'}</li>`;
    return;
  }
  el.innerHTML = items.map(({ d, m }) => {
    const c = cardOf(d.cardId), k = colorOf(c);
    return `<li><button class="row" data-act="open" data-id="${esc(d.id)}">
      <span class="av" style="--a:${k.a};--b:${k.b}">${esc(initial(d.shop))}</span>
      <span class="rm"><b>${esc(d.shop)}</b><span class="rcard"><span class="dot" style="background:${k.s}"></span><span>${esc(c ? c.name : 'No card')}</span></span></span>
      <span class="rr"><span class="val">${esc(d.value)}</span>${m != null ? `<span class="dd">${fmtDist(m)}</span>` : ''}</span>
    </button></li>`;
  }).join('');
}

function syncNearBtn() {
  const b = $('#nearbtn');
  b.classList.toggle('on', ui.nearest);
  b.setAttribute('aria-pressed', String(ui.nearest));
}

/* ------------------------------ sheets ------------------------------- */
const sheetEl = $('#sheet'), scrimEl = $('#scrim');
let sheetOpen = false, pickerOpen = false, ignorePop = 0;

function pushLayer() { history.pushState({ layer: 1 }, ''); }
function popLayer() { ignorePop++; history.back(); }
window.addEventListener('popstate', () => {
  if (ignorePop > 0) { ignorePop--; return; }
  if (pickerOpen) hidePicker();
  else if (sheetOpen) hideSheet();
});

function openSheet(html) {
  sheetEl.innerHTML = `<div class="grab"></div>${html}`;
  if (!sheetOpen) { pushLayer(); sheetOpen = true; }
  sheetEl.classList.add('on');
  scrimEl.classList.add('on');
  const body = $('.sheet-body', sheetEl);
  if (body) body.scrollTop = 0;
}
function hideSheet() {
  sheetOpen = false;
  sheetEl.classList.remove('on');
  scrimEl.classList.remove('on');
  clearTimeout(armTimer);
}
function closeSheet() {
  if (!sheetOpen) return;
  hideSheet();
  popLayer();
}

/* ------------------------------ card form ------------------------------ */
let cdraft = null, cnext = null;
function openCardForm(id, next) {
  const ex = id ? cardOf(id) : null;
  cnext = next || null;
  cdraft = ex ? { ...ex } : { name: '', color: S.cards.length % COLORS.length };
  const n = ex ? S.discounts.filter((d) => d.cardId === ex.id).length : 0;
  openSheet(`<div class="sheet-body">
    <h2>${ex ? 'Edit card' : 'New card'}</h2>
    <div class="prevwrap"><div id="cprev" class="wcard" style="--a:${colorOf(cdraft).a};--b:${colorOf(cdraft).b}">
      <div class="cname">${esc(cdraft.name) || 'Card name'}</div><div class="ccount">${n} ${n === 1 ? 'discount' : 'discounts'}</div></div></div>
    <div class="field" id="cf-name"><label for="c-name">Name</label><input id="c-name" type="text" maxlength="40" autocomplete="off" autocapitalize="words" placeholder="e.g. Work perks, Tennis club" value="${esc(cdraft.name)}"></div>
    <div class="field"><span class="lbl">Colour</span><div class="swatches" id="c-sw">${COLORS.map((k, i) =>
      `<button type="button" class="sw${cdraft.color === i ? ' on' : ''}" data-act="color" data-i="${i}" style="--a:${k.a};--b:${k.b}" aria-label="Colour ${i + 1}"></button>`).join('')}</div></div>
  </div>
  <div class="sheet-foot">
    ${ex ? `<button class="btn danger" data-act="delcard" data-id="${esc(ex.id)}" aria-label="Delete card">${I.trash}</button>` : '<button class="btn ghost" data-act="close">Cancel</button>'}
    <button class="btn primary" data-act="savecard">${ex ? 'Save changes' : 'Add card'}</button>
  </div>`);
  const inp = $('#c-name');
  inp.addEventListener('input', () => {
    cdraft.name = inp.value;
    $('#cprev .cname').textContent = inp.value.trim() || 'Card name';
    $('#cf-name').classList.remove('bad');
  });
  if (!ex) setTimeout(() => inp.focus(), 320);
}

function saveCard() {
  const name = ($('#c-name').value || '').trim();
  if (!name) { $('#cf-name').classList.add('bad'); $('#c-name').focus(); toast('Give the card a name'); return; }
  let id = cdraft.id;
  if (id) {
    const c = cardOf(id); c.name = name; c.color = cdraft.color;
  } else {
    id = uid(); S.cards.push({ id, name, color: cdraft.color });
  }
  save();
  renderAll();
  if (cnext === 'discount') { openDiscountForm(null, id); return; }
  closeSheet();
  toast('Saved');
}

/* ---------------------------- discount form ---------------------------- */
let draft = null;
let srch = { results: [], status: 'idle', level: 0, q: '' };
let srchTimer, srchAbort;

function openDiscountForm(id, presetCard) {
  if (!S.cards.length) { openCardForm(null, 'discount'); toast('Add a card first'); return; }
  const ex = id ? S.discounts.find((d) => d.id === id) : null;
  draft = ex ? structuredClone(ex) : { cardId: presetCard || ui.cardId || S.cards[0].id, shop: '', value: '', notes: '', category: '', places: [] };
  if (!cardOf(draft.cardId)) draft.cardId = S.cards[0].id;
  clearTimeout(srchTimer); srchAbort && srchAbort.abort();
  srch = { results: [], status: 'idle', level: 0, q: '' };

  openSheet(`<div class="sheet-body">
    <h2>${ex ? 'Edit discount' : 'New discount'}</h2>
    <div class="field"><span class="lbl">Card</span><div class="pills" id="f-cards">${S.cards.map((c) => {
      const k = colorOf(c);
      return `<button type="button" class="pill${draft.cardId === c.id ? ' on' : ''}" data-act="fcard" data-id="${esc(c.id)}"><span class="dot" style="background:${k.s}"></span>${esc(c.name)}</button>`;
    }).join('')}</div></div>
    <div class="field" id="ff-shop"><label for="f-shop">Shop or restaurant</label>
      <input id="f-shop" type="text" autocomplete="off" autocapitalize="words" enterkeyhint="search" placeholder="e.g. Starbucks" value="${esc(draft.shop)}"></div>
    <div class="places" id="f-places"></div>
    <div class="field" id="ff-val"><label for="f-val">Discount</label>
      <input id="f-val" type="text" maxlength="40" autocomplete="off" placeholder="e.g. 15% off, 2 for 1, free dessert" value="${esc(draft.value)}"></div>
    <div class="field"><span class="lbl">Category (optional)</span><div class="pills" id="f-cats">${CATS.map((c) =>
      `<button type="button" class="pill${draft.category === c ? ' on' : ''}" data-act="fcat" data-v="${c}">${c}</button>`).join('')}</div></div>
    <div class="field"><label for="f-notes">Conditions (optional)</label>
      <textarea id="f-notes" rows="2" placeholder="Days, minimum spend, how to claim">${esc(draft.notes)}</textarea></div>
  </div>
  <div class="sheet-foot">
    ${ex ? `<button class="btn danger" data-act="deldiscount" data-id="${esc(ex.id)}" aria-label="Delete discount">${I.trash}</button>` : '<button class="btn ghost" data-act="close">Cancel</button>'}
    <button class="btn primary" data-act="savediscount">${ex ? 'Save changes' : 'Add discount'}</button>
  </div>`);

  const shop = $('#f-shop');
  shop.addEventListener('input', () => {
    draft.shop = shop.value;
    $('#ff-shop').classList.remove('bad');
    clearTimeout(srchTimer);
    const q = shop.value.trim();
    if (q.length < 3) { srchAbort && srchAbort.abort(); srch = { results: [], status: 'idle', level: 0, q: '' }; renderPlaces(); return; }
    srchTimer = setTimeout(() => runSearch(q, 0), 850);
  });
  shop.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); clearTimeout(srchTimer); const q = shop.value.trim(); if (q) { shop.blur(); runSearch(q, 0); } }
  });
  $('#f-val').addEventListener('input', () => $('#ff-val').classList.remove('bad'));
  renderPlaces();
  if (!ex) setTimeout(() => shop.focus(), 340);
}

function renderPlaces() {
  const el = $('#f-places');
  if (!el) return;
  const sel = draft.places.map((p) => `<div class="pchip">${I.pin}<span class="pn"><b>${esc(p.name)}</b><small>${esc(p.address || (p.manual ? 'Pinned on the map' : ''))}</small></span>
    <button type="button" data-act="rmplace" data-pid="${esc(p.id)}" aria-label="Remove location">${I.close}</button></div>`).join('');

  let res = '';
  if (srch.status === 'loading') {
    res = `<div class="note"><span class="spin"></span>Looking for “${esc(srch.q)}”…</div>`;
  } else if (srch.status === 'error') {
    res = `<div class="note warn">Couldn’t reach place search. Check your connection, or drop a pin instead.</div>`;
  } else if (srch.status === 'done') {
    if (!srch.results.length) {
      res = `<div class="note">No matches for “${esc(srch.q)}”. Try another spelling, or drop a pin on the map.</div>`;
    } else {
      const label = ['Near you', 'Within about 150 km', 'Anywhere'][srch.level] || '';
      res = `<div class="reslabel">${label}. Tap the branches you can use.</div><div class="results">` + srch.results.map((r) => {
        const on = draft.places.some((p) => p.id === r.id);
        const m = geo.pos ? dist(geo.pos, r) : null;
        return `<button type="button" class="res${on ? ' on' : ''}" data-act="toggleplace" data-pid="${esc(r.id)}">
          <span class="tick">${on ? I.check : ''}</span>
          <span class="rt"><b>${esc(r.name)}</b><small>${esc(r.address || '')}</small></span>
          ${m != null ? `<span class="rd">${fmtDist(m)}</span>` : ''}</button>`;
      }).join('') + '</div>';
    }
    if (srch.level < 2) res += `<button type="button" class="btn soft sm" data-act="wider">Not here? Search wider</button>`;
  }

  el.innerHTML = `<span class="lbl">Where it applies</span>
    ${sel ? `<div class="pchips">${sel}</div>` : ''}
    ${res}
    <div class="pbtns" style="margin-top:${res ? 10 : 0}px">
      <button type="button" class="btn soft sm" data-act="findplaces">${I.search}Find branches</button>
      <button type="button" class="btn soft sm" data-act="pickonmap">${I.pin}Pick on map</button>
    </div>`;
}

/* ---- place search (OpenStreetMap Nominatim) ---- */
function fmtAddr(a) {
  if (!a) return '';
  const street = [a.road || a.pedestrian || a.footway, a.house_number].filter(Boolean).join(' ');
  const area = a.suburb || a.neighbourhood || a.city_district || '';
  const city = a.city || a.town || a.village || a.municipality || '';
  return [...new Set([street, area, city].filter(Boolean))].join(', ');
}
function parseResult(r, q) {
  return {
    id: String(r.osm_type || 'x') + String(r.osm_id || uid()),
    name: r.name || (draft && draft.shop && draft.shop.trim()) || q,
    address: fmtAddr(r.address) || String(r.display_name || '').split(',').slice(0, 3).join(',').trim(),
    lat: +r.lat,
    lon: +r.lon
  };
}
async function nominatim(q, level, c, signal) {
  const p = new URLSearchParams({ q, format: 'jsonv2', addressdetails: '1', limit: '15', 'accept-language': LANG });
  if (level < 2 && c) {
    const d = level === 0 ? 0.22 : 1.4;
    const dl = d / Math.max(0.2, Math.cos(c.lat * Math.PI / 180));
    p.set('viewbox', [c.lon - dl, c.lat + d, c.lon + dl, c.lat - d].join(','));
    p.set('bounded', '1');
  }
  const r = await fetch('https://nominatim.openstreetmap.org/search?' + p, { signal });
  if (!r.ok) throw new Error('http ' + r.status);
  const j = await r.json();
  const seen = new Set(), out = [];
  j.forEach((x) => {
    const o = parseResult(x, q);
    if (!seen.has(o.id)) { seen.add(o.id); out.push(o); }
  });
  if (c) out.sort((a, b) => dist(c, a) - dist(c, b));
  return out;
}
async function runSearch(q, level) {
  clearTimeout(srchTimer);
  srchAbort && srchAbort.abort();
  const ctl = srchAbort = new AbortController();
  srch = { results: srch.results, status: 'loading', level, q };
  renderPlaces();
  if (level === 0 && !geo.pos) await ensurePosition(3500);
  if (ctl.signal.aborted) return;
  const c = geo.pos;
  if (level < 2 && !c) level = 2;
  try {
    let lvl = level, out = [];
    for (; lvl <= 2; lvl++) {
      out = await nominatim(q, lvl, c, ctl.signal);
      if (out.length) break;
    }
    if (ctl.signal.aborted) return;
    srch = { results: out, status: 'done', level: Math.min(lvl, 2), q };
  } catch (e) {
    if (e.name === 'AbortError') return;
    srch = { results: [], status: 'error', level, q };
  }
  renderPlaces();
}

/* ---- pick a spot on the map ---- */
let pick = null, pickTiles = null;
function openPicker(start) {
  const el = $('#picker');
  el.classList.add('on');
  el.setAttribute('aria-hidden', 'false');
  if (!pickerOpen) { pushLayer(); pickerOpen = true; }
  if (typeof L === 'undefined') { toast('The map couldn’t load.'); return; }
  if (!pick) {
    pick = L.map('pickmap', { zoomControl: false, attributionControl: false });
    pickTiles = mkTiles().addTo(pick);
    L.control.attribution({ prefix: false, position: 'bottomleft' }).addTo(pick);
  }
  pick.invalidateSize();
  pick.setView([start.lat, start.lon], start.z || 16);
}
function hidePicker() {
  pickerOpen = false;
  const el = $('#picker');
  el.classList.remove('on');
  el.setAttribute('aria-hidden', 'true');
}
function closePicker() {
  if (!pickerOpen) return;
  hidePicker();
  popLayer();
}
function startPick() {
  const last = draft.places[draft.places.length - 1];
  let start;
  if (last) start = { lat: last.lat, lon: last.lon, z: 17 };
  else if (geo.pos) start = { lat: geo.pos.lat, lon: geo.pos.lon, z: 17 };
  else if (srch.results[0]) start = { lat: srch.results[0].lat, lon: srch.results[0].lon, z: 15 };
  else start = { lat: DEFAULT_CENTER[0], lon: DEFAULT_CENTER[1], z: 12 };
  enableLocation();
  openPicker(start);
}
async function fetchT(url, ms) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try { return await fetch(url, { signal: ctl.signal }); } finally { clearTimeout(t); }
}
async function reverse(lat, lon) {
  try {
    const r = await fetchT(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1&accept-language=${LANG}`, 5000);
    const j = await r.json();
    return { name: j.name || '', address: fmtAddr(j.address) || String(j.display_name || '').split(',').slice(0, 3).join(',').trim() };
  } catch (e) { return { name: '', address: '' }; }
}
async function confirmPick() {
  const btn = $('#pickok');
  btn.disabled = true; btn.textContent = 'Finding the address…';
  const c = pick.getCenter();
  const r = await reverse(c.lat, c.lng);
  const shop = ($('#f-shop') && $('#f-shop').value.trim()) || '';
  draft.places.push({ id: 'pin' + uid(), name: shop || r.name || 'Pinned spot', address: r.address, lat: +c.lat.toFixed(6), lon: +c.lng.toFixed(6), manual: true });
  btn.disabled = false; btn.textContent = 'Use this spot';
  closePicker();
  renderPlaces();
}

/* ---- save / delete discount ---- */
function saveDiscount() {
  const shop = $('#f-shop').value.trim();
  const value = $('#f-val').value.trim();
  if (!shop) { $('#ff-shop').classList.add('bad'); $('#f-shop').focus(); toast('Add the shop or restaurant name'); return; }
  if (!value) { $('#ff-val').classList.add('bad'); $('#f-val').focus(); toast('Add the discount, like 15% off'); return; }
  const o = { ...draft, shop, value, notes: $('#f-notes').value.trim() };
  if (o.id) {
    const i = S.discounts.findIndex((d) => d.id === o.id);
    if (i >= 0) S.discounts[i] = o;
  } else {
    o.id = uid(); o.createdAt = Date.now(); S.discounts.push(o);
  }
  save();
  renderAll();
  closeSheet();
  toast('Saved');
}

/* ------------------------------- detail ------------------------------- */
function openDetail(id) {
  const d = S.discounts.find((x) => x.id === id);
  if (!d) return;
  const c = cardOf(d.cardId), k = colorOf(c);
  const others = S.discounts.filter((x) => x.id !== d.id && norm(x.shop) === norm(d.shop));
  const places = (d.places || []).map((p) => {
    const m = geo.pos ? dist(geo.pos, p) : null;
    return `<div class="drow">${I.pin}<span class="pn"><b>${esc(p.name)}</b><small>${esc([p.address, m != null ? fmtDist(m) + ' away' : ''].filter(Boolean).join('  ·  '))}</small></span>
      <button class="mini" data-act="showmap" data-id="${esc(d.id)}" data-pid="${esc(p.id)}" aria-label="Show on map">${I.map}</button>
      <a class="mini" href="https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lon}" target="_blank" rel="noopener" aria-label="Directions">${I.nav}</a></div>`;
  }).join('');
  openSheet(`<div class="sheet-body">
    <div class="dhead"><span class="av lg" style="--a:${k.a};--b:${k.b}">${esc(initial(d.shop))}</span>
      <div><div class="dshop">${esc(d.shop)}</div><div class="dcard"><span class="dot" style="background:${k.s}"></span>${esc(c ? c.name : 'No card')}</div></div></div>
    <div class="dval">${esc(d.value)}</div>
    ${d.category ? `<span class="dcat">${esc(d.category)}</span>` : ''}
    ${d.notes ? `<p class="dnotes">${esc(d.notes)}</p>` : ''}
    ${others.length ? others.map((o) => { const oc = cardOf(o.cardId); return `<div class="also">Also here with <b>${esc(oc ? oc.name : 'another card')}</b>: ${esc(o.value)}</div>`; }).join('') : ''}
    <h3>Where</h3>
    ${places || `<p class="hint">No location saved yet. Edit this discount to add the branches.</p>`}
  </div>
  <div class="sheet-foot"><button class="btn ghost" data-act="close">Close</button><button class="btn primary" data-act="editdiscount" data-id="${esc(d.id)}">${I.edit}Edit</button></div>`);
}

/* ------------------------------- backup ------------------------------- */
let pendingImport = null;
function openBackup() {
  pendingImport = null;
  openSheet(`<div class="sheet-body">
    <h2>Backup and restore</h2>
    <p class="hint" style="margin-bottom:16px">Everything lives on this phone. Export a file now and then so you never lose your cards.</p>
    <div class="stack">
      <button class="btn soft" data-act="export">${I.down}Export backup</button>
      <button class="btn soft" data-act="import">${I.up}Import backup</button>
    </div>
    <div id="imp"></div>
  </div>
  <div class="sheet-foot"><button class="btn ghost wide" data-act="close">Done</button></div>`);
}
async function exportData() {
  const name = `dibs-backup-${new Date().toISOString().slice(0, 10)}.json`;
  const text = JSON.stringify(S, null, 2);
  const P = window.Capacitor && window.Capacitor.Plugins;
  if (P && P.Filesystem && P.Share) {
    try {
      const r = await P.Filesystem.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
      await P.Share.share({ title: 'Dibs backup', url: r.uri, dialogTitle: 'Save your backup' });
    } catch (e) {
      if (!/cancel/i.test(String(e && (e.message || e)))) toast('Couldn’t export the backup');
    }
    return;
  }
  const blob = new Blob([text], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  toast('Backup exported');
}
function validData(j) {
  return j && Array.isArray(j.cards) && Array.isArray(j.discounts) &&
    j.cards.every((c) => c && typeof c.id === 'string' && typeof c.name === 'string') &&
    j.discounts.every((d) => d && typeof d.id === 'string' && typeof d.shop === 'string');
}
$('#importfile').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  e.target.value = '';
  if (!f) return;
  try {
    const j = JSON.parse(await f.text());
    if (!validData(j)) throw new Error('shape');
    pendingImport = { cards: j.cards, discounts: j.discounts };
    const box = $('#imp');
    if (box) box.innerHTML = `<p class="hint">This file has ${j.cards.length} ${j.cards.length === 1 ? 'card' : 'cards'} and ${j.discounts.length} ${j.discounts.length === 1 ? 'discount' : 'discounts'}. Importing replaces what’s on this phone now.</p><button class="btn danger" data-act="doimport">Replace my data</button>`;
  } catch (err) {
    toast('That file isn’t a Dibs backup');
  }
});

/* -------------------------------- map -------------------------------- */
let map = null, tilesMain = null, markersLayer = null, meMarker = null, meCircle = null;
const mkTiles = () => L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, className: 'osm-tiles', attribution: '© OpenStreetMap contributors' });

function pinIcon(hex, label) {
  return L.divIcon({ className: 'pin-wrap', html: `<div class="pin" style="--pc:${hex}"><span>${esc(label)}</span></div>`, iconSize: [34, 34], iconAnchor: [17, 41] });
}

function initMap() {
  if (map) return;
  if (typeof L === 'undefined') { toast('The map couldn’t load.'); return; }
  map = L.map('map', { zoomControl: false, attributionControl: false }).setView(DEFAULT_CENTER, 12);
  L.control.attribution({ prefix: false, position: 'bottomleft' }).addTo(map);
  tilesMain = mkTiles().addTo(map);
  markersLayer = L.layerGroup().addTo(map);
  map.on('click', closePeek);
  map.on('dragstart', () => { ui.mapMoved = true; });
  drawPins();
  updateMeMarker();
  if (geo.pos) map.setView([geo.pos.lat, geo.pos.lon], 14);
  else fitPins(false);
}

function pinGroups() {
  const g = new Map();
  S.discounts.filter((d) => !ui.mapCard || d.cardId === ui.mapCard).forEach((d) => {
    (d.places || []).forEach((p) => {
      const key = p.lat.toFixed(4) + ',' + p.lon.toFixed(4);
      if (!g.has(key)) g.set(key, { key, lat: p.lat, lon: p.lon, items: [] });
      g.get(key).items.push({ d, p });
    });
  });
  return [...g.values()];
}

function drawPins() {
  if (!map) return;
  markersLayer.clearLayers();
  pinGroups().forEach((g) => {
    const first = g.items[0].d;
    const label = g.items.length > 1 ? String(g.items.length) : initial(first.shop);
    L.marker([g.lat, g.lon], { icon: pinIcon(discColor(first).s, label), keyboard: false })
      .on('click', () => openPeek(g.key))
      .addTo(markersLayer);
  });
}

function renderMapChips() {
  const el = $('#mapchips');
  if (!S.cards.length) { el.innerHTML = ''; return; }
  if (ui.mapCard && !cardOf(ui.mapCard)) ui.mapCard = null;
  el.innerHTML = [`<button class="chip${!ui.mapCard ? ' on' : ''}" data-act="mapcard" data-id="">All cards</button>`,
    ...S.cards.map((c) => `<button class="chip${ui.mapCard === c.id ? ' on' : ''}" data-act="mapcard" data-id="${esc(c.id)}"><span class="dot" style="background:${colorOf(c).s}"></span>${esc(c.name)}</button>`)].join('');
}

function updateMeMarker() {
  if (!map || !geo.pos) return;
  const ll = [geo.pos.lat, geo.pos.lon];
  if (!meMarker) {
    meMarker = L.marker(ll, { icon: L.divIcon({ className: 'me-wrap', html: '<div class="me"><i></i></div>', iconSize: [20, 20], iconAnchor: [10, 10] }), interactive: false, keyboard: false, zIndexOffset: 1000 }).addTo(map);
  } else meMarker.setLatLng(ll);
  if (geo.pos.acc && geo.pos.acc < 400) {
    if (!meCircle) meCircle = L.circle(ll, { radius: geo.pos.acc, stroke: false, fillColor: '#2F6BFF', fillOpacity: 0.1, interactive: false }).addTo(map);
    else meCircle.setLatLng(ll).setRadius(geo.pos.acc);
  }
}

function flyToMe() {
  if (!map || !geo.pos) return;
  map.flyTo([geo.pos.lat, geo.pos.lon], Math.max(map.getZoom(), 15), { duration: 0.8 });
}
async function locateMe() {
  initMap();
  if (!map) return;
  if (!geo.pos) {
    if (geo.denied) { toast('Location is off. Allow it for Dibs in Android settings → Apps → Dibs → Permissions.'); return; }
    toast('Finding you…');
    await ensurePosition(8000);
  }
  if (geo.pos) { ui.mapMoved = false; flyToMe(); } else if (!geo.denied) toast('Couldn’t get your location yet.');
}
function fitPins(announce = true) {
  if (!map) return;
  const gs = pinGroups();
  if (!gs.length) { if (announce) toast('No pinned shops yet'); return; }
  map.fitBounds(L.latLngBounds(gs.map((g) => [g.lat, g.lon])), { padding: [60, 60], maxZoom: 16 });
}

function openPeek(key) {
  const g = pinGroups().find((x) => x.key === key);
  if (!g) return;
  const first = g.items[0].p;
  const m = geo.pos ? dist(geo.pos, g) : null;
  const el = $('#peek');
  el.innerHTML = `<div class="peekhead"><div><b>${esc(first.name || g.items[0].d.shop)}</b>
      ${first.address ? `<small>${esc(first.address)}</small>` : ''}${m != null ? `<small>${fmtDist(m)} away</small>` : ''}</div>
      <a class="dirbtn" href="https://www.google.com/maps/dir/?api=1&destination=${g.lat},${g.lon}" target="_blank" rel="noopener">${I.nav}Directions</a></div>` +
    g.items.map(({ d }) => {
      const c = cardOf(d.cardId), k = colorOf(c);
      return `<button class="prow" data-act="open" data-id="${esc(d.id)}"><span class="dot" style="background:${k.s}"></span>
        <span class="pr1"><b>${esc(d.shop)}</b><small>${esc(c ? c.name : '')}</small></span><span class="val">${esc(d.value)}</span></button>`;
    }).join('');
  el.classList.add('on');
  if (map) {
    const pt = map.project([g.lat, g.lon]).add([0, 110]);
    map.panTo(map.unproject(pt), { animate: true });
  }
}
function closePeek() { $('#peek').classList.remove('on'); }

function focusOnMap(discountId, placeId) {
  const d = S.discounts.find((x) => x.id === discountId);
  const p = d && (d.places || []).find((x) => x.id === placeId);
  closeSheet();
  setTab('map');
  if (!map || !p) return;
  ui.mapCard = null; renderMapChips(); drawPins();
  ui.mapMoved = true;
  map.setView([p.lat, p.lon], 17);
  setTimeout(() => openPeek(p.lat.toFixed(4) + ',' + p.lon.toFixed(4)), 60);
}

/* ------------------------------- tabs ------------------------------- */
function setTab(t) {
  ui.tab = t;
  $('#view-wallet').classList.toggle('on', t === 'wallet');
  $('#view-map').classList.toggle('on', t === 'map');
  $$('.tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
  if (t === 'map') {
    initMap();
    enableLocation();
    renderMapChips();
    if (map) setTimeout(() => map.invalidateSize(), 30);
  } else {
    closePeek();
    renderList();
  }
  window.scrollTo(0, 0);
}

/* ------------------------------ delete helpers ------------------------------ */
let armTimer;
function armed(btn, label) {
  if (btn.dataset.armed) return true;
  btn.dataset.armed = '1';
  btn.dataset.label = btn.innerHTML;
  btn.classList.add('armed');
  btn.innerHTML = label;
  clearTimeout(armTimer);
  armTimer = setTimeout(() => {
    if (btn.isConnected) { delete btn.dataset.armed; btn.classList.remove('armed'); btn.innerHTML = btn.dataset.label; }
  }, 3500);
  return false;
}

/* ------------------------------ events ------------------------------ */
document.addEventListener('click', async (e) => {
  const t = e.target.closest('[data-act]');
  if (!t) return;
  const act = t.dataset.act, id = t.dataset.id;
  switch (act) {
    case 'tab': setTab(t.dataset.tab); break;
    case 'add': openDiscountForm(null); break;
    case 'newcard': openCardForm(null); break;
    case 'editcard': e.stopPropagation(); openCardForm(id); break;
    case 'pickcard': ui.cardId = ui.cardId === id ? null : id; renderWallet(); break;
    case 'cat': ui.cat = t.dataset.v || ''; renderChips(); renderList(); break;
    case 'nearest':
      ui.nearest = !ui.nearest; syncNearBtn();
      if (ui.nearest) {
        if (geo.denied) { ui.nearest = false; syncNearBtn(); toast('Location is off. Allow it for Dibs in Android settings → Apps → Dibs → Permissions.'); }
        else { enableLocation(); if (!geo.pos) toast('Finding you…'); }
      }
      renderList();
      break;
    case 'open': openDetail(id); break;
    case 'backup': openBackup(); break;
    case 'close': closeSheet(); break;
    case 'color':
      cdraft.color = +t.dataset.i;
      $$('#c-sw .sw').forEach((b) => b.classList.toggle('on', +b.dataset.i === cdraft.color));
      { const k = COLORS[cdraft.color]; const p = $('#cprev'); p.style.setProperty('--a', k.a); p.style.setProperty('--b', k.b); }
      break;
    case 'savecard': saveCard(); break;
    case 'delcard': {
      if (!armed(t, 'Tap again to delete')) break;
      S.cards = S.cards.filter((c) => c.id !== id);
      S.discounts = S.discounts.filter((d) => d.cardId !== id);
      if (ui.cardId === id) ui.cardId = null;
      save(); renderAll(); closeSheet(); toast('Card deleted');
      break;
    }
    case 'fcard':
      draft.cardId = id;
      $$('#f-cards .pill').forEach((b) => b.classList.toggle('on', b.dataset.id === id));
      break;
    case 'fcat':
      draft.category = draft.category === t.dataset.v ? '' : t.dataset.v;
      $$('#f-cats .pill').forEach((b) => b.classList.toggle('on', b.dataset.v === draft.category));
      break;
    case 'findplaces': {
      const q = ($('#f-shop').value || '').trim();
      if (q.length < 2) { $('#ff-shop').classList.add('bad'); $('#f-shop').focus(); toast('Type the shop name first'); break; }
      runSearch(q, 0);
      break;
    }
    case 'wider': runSearch(srch.q, Math.min(2, srch.level + 1)); break;
    case 'toggleplace': {
      const pid = t.dataset.pid;
      const i = draft.places.findIndex((p) => p.id === pid);
      if (i >= 0) draft.places.splice(i, 1);
      else { const r = srch.results.find((x) => x.id === pid); if (r) draft.places.push({ ...r }); }
      renderPlaces();
      break;
    }
    case 'rmplace': draft.places = draft.places.filter((p) => p.id !== t.dataset.pid); renderPlaces(); break;
    case 'pickonmap': startPick(); break;
    case 'pickcancel': closePicker(); break;
    case 'pickconfirm': confirmPick(); break;
    case 'picklocate':
      if (geo.pos && pick) pick.setView([geo.pos.lat, geo.pos.lon], 17);
      else { toast('Finding you…'); ensurePosition(8000).then((p) => { if (p && pick) pick.setView([p.lat, p.lon], 17); }); }
      break;
    case 'savediscount': saveDiscount(); break;
    case 'deldiscount':
      if (!armed(t, 'Tap again to delete')) break;
      S.discounts = S.discounts.filter((d) => d.id !== id);
      save(); renderAll(); closeSheet(); toast('Discount deleted');
      break;
    case 'editdiscount': openDiscountForm(id); break;
    case 'showmap': focusOnMap(id, t.dataset.pid); break;
    case 'mapcard': ui.mapCard = id || null; renderMapChips(); drawPins(); closePeek(); break;
    case 'locate': locateMe(); break;
    case 'fitall': initMap(); fitPins(); break;
    case 'export': exportData(); break;
    case 'import': $('#importfile').click(); break;
    case 'doimport':
      if (!pendingImport) break;
      S = pendingImport; pendingImport = null;
      ui.cardId = null; ui.mapCard = null;
      save(); renderAll(); closeSheet(); toast('Backup restored');
      break;
  }
});

document.addEventListener('keydown', (e) => {
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[role=button][data-act]')) {
    e.preventDefault();
    e.target.click();
  }
});

$('#q').addEventListener('input', (e) => { ui.q = e.target.value; renderList(); });

/* ------------------------------- boot ------------------------------- */
function init() {
  $$('[data-i]').forEach((el) => { el.innerHTML = I[el.dataset.i] || ''; });
  renderAll();

  // If location was already allowed, start quietly; otherwise wait until it's needed.
  if (navigator.permissions && navigator.permissions.query) {
    navigator.permissions.query({ name: 'geolocation' }).then((p) => {
      if (p.state === 'granted') enableLocation();
      p.onchange = () => { if (p.state === 'granted') { geo.denied = false; enableLocation(); } else if (p.state === 'denied') { geo.denied = true; stopWatch(); } };
    }).catch(() => {});
  }
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
}
init();
